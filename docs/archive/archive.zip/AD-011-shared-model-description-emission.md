---
id: AD-011
title: modelDescription emission moves to pyfmi_interfaces
summary: One emitter in pyfmi_interfaces renders the Co-Simulation modelDescription with canonical VendorAnnotations; this repo supplies the GUID, the CsFmuPackager payload, the FMI facade, and the solver, and keeps no legacy document layout.
date: 2026-11-22
status: accepted
layers: [architecture, implementation]
state: 02-architecture/component-view.md
artifacts:
  - src/cs_fmu_packager/model_description.py
  - src/cs_fmu_packager/guid.py
  - src/cs_fmu_packager/codegen/fmi_interface.py
  - pyproject.toml
supersedes: []
superseded_by: []
related: []
---

# AD-011: modelDescription emission moves to pyfmi_interfaces

## Context

The repository wrote its own FMI 2.0 `modelDescription.xml` string and kept GUID derivation inside that writer.
The same FMI document model already exists in `pyfmi_interfaces`, but its FMI 2.0 extension point, `VendorAnnotations`, was not modelled.
Two writers for one FMI document spell the same fields twice and let the two drift.

## Decision

`pyfmi_interfaces` owns the FMI 2.0 document and its emission, including the ordered, tool-independent annotation mechanism.
There is exactly one emitter: `model_description/document.py` renders the document through the library codec and inserts a canonical `VendorAnnotations` block at the schema position; no canonical/expanded layout switch remains.
`cs_fmu_packager` builds that document and supplies one annotation named `cs-fmu-packager` containing the `<CsFmuPackager>` metadata and the `<InternalConnections>` graph.
GUID derivation (MD5 of specification content) stays package data in `src/cs_fmu_packager/guid.py`, and both the writer and the FMI facade import it from there; the FMI facade and solver codegen stay local.

## Rationale

One FMI document model means one place that knows FMI 2.0 element order, capability flags, variables, and model structure.
The tool-specific payload is data, not a second serializer, and the extension point keeps the shared model tool-agnostic.
The GUID remains unchanged because identity must survive the move.

## Alternatives Considered

- Keep the local writer and add annotation support only to `pyfmi_interfaces` for future consumers: leaves two FMI 2.0 writers and the drift this record removes.
- Model `VendorAnnotations` upstream in `experimental_pyssp_standard`: the right long-term home, but it is an external pinned wheel and outside this repository's change boundary.
- Migrate the FMI facade and solver codegen too: out of scope; those are Co-Simulation wrapper behaviour, not FMI document emission.

## Consequences

- Positive: one FMI 2.0 document model and one emitter; annotation placement and ordering are shared and tested once.
- Positive: the emitted document has the same elements, order, attributes, and opaque payload as the previous writer; only formatting changed when the legacy expanded spelling was deleted.
- Positive: `_derive_guid` no longer sits on the XML writer path; the facade imports `cs_fmu_packager.guid.derive_guid`.
- Negative: the library codec omits an empty `dependencies` list, so `ModelStructure/Outputs/Unknown` no longer spells `dependencies=""`. FMI reads an absent list as the default (depends on all Knowns) instead of the explicit empty list (depends on none); the wrapper does not consume this metadata and its outputs are pass-throughs.
- Negative: `cs-fmu-packager` now has a hard dependency on `pyfmi-interfaces`.

## Verification

- `tests/test_codegen.py` exercises the document, variable order, GUID sensitivity, and a round trip through the FMI 2.0 codec.
- The full `pytest` suite passes; an element-tree comparison of the old expanded document and the new canonical document shows the same elements, order, attributes, and payload after ignoring whitespace, with the empty-`dependencies` difference above.
- `pyfmi_interfaces` validates both a plain and an annotated emitted document against the FMI 2.0 XSD shipped by `pyssp_standard`.

## Review Trigger

Revisit when `experimental_pyssp_standard` models `VendorAnnotations` natively, or when the library codec can spell an explicit empty dependency list.
